import React from 'react';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import ListStudentComponent from './components/ListStudentComponent'
import CreateStudentComponent from './components/CreateStudentComponent'
import ViewStudentComponent from './components/ViewStudentComponent'
import UpdateStudentComponent from './components/UpdateStudentComponent'
import HeaderComponent from './components/HeaderComponent'
import FooterComponent from './components/FooterComponent'
import PageError from './components/PageError';
import Admin_Panel from './components/Admin_Panel';
function App() {
  return (
    
    <div className="">
        <Router>
              <HeaderComponent />
                <div>
                    <Switch> 
                          <Route path = "/" exact component = {ListStudentComponent}></Route>
                          <Route path = "/student" component = {ListStudentComponent}></Route>
                          <Route path = "/add-student/:id" component = {CreateStudentComponent}></Route>
                          <Route path = "/view-student/:id" component = {ViewStudentComponent}></Route>
                          <Route path = "/update-student/:id" component = {UpdateStudentComponent}></Route>
                          <Route path="/admin-panel" component = {Admin_Panel}></Route>
                          <Route component={PageError}></Route>
                    </Switch>
                </div>
              <FooterComponent />
        </Router>
    </div>
   
  );
}

export default App;
