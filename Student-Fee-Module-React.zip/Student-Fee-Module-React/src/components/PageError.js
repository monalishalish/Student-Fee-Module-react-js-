import React from 'react'
import { Link } from 'react-router-dom'

export default function PageError() {
    return (
        <div>
            <div>
                <h1>404</h1>
                <p>This page is not available</p>
                <h3><Link to="/"> Home</Link> </h3>
            </div>
        </div>
    )
}
