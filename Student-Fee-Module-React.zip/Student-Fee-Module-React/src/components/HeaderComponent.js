import React, { Component } from 'react'
// import logo from '../logo.png'

class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <header>
                    <nav className="navbar">
                    <div>
                       
                            {/* <a className="navbar-brand" href="#"> */}
                                {/* <img src={logo} alt="logo" className="logo" /> */}
                            {/* </a> */}
                        {/* <a href="https://www.ankitkumar.engineer" className="navbar-brand">Student Fee Module</a> */}
                        </div>
                    </nav>
                </header>
            </div>
        )
    }
}

export default HeaderComponent
